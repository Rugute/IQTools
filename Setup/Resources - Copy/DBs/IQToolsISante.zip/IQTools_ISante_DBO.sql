-- MySQL dump 10.11
--
-- Host: localhostDatabase: dbo
-- ------------------------------------------------------
-- Server version5.0.51a-24+lenny5

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `dbo`
--

/*!40000 DROP DATABASE IF EXISTS `dbo`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dbo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbo`;

--
-- Dumping routines for database 'dbo'
--
DELIMITER ;;
/*!50003 DROP FUNCTION IF EXISTS `fn_CDCRegimens` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_CDCRegimens`(Regimen varchar(50), RegType varchar(50)) RETURNS varchar(20) CHARSET latin1 Begin If(RegType='isante') Then If Regimen In ('d4T-3TC-NVP') Then Return '3TC/D4T30/NVP';ElseIf Regimen In ('d4T-3TC-EFV') Then Return '3TC/D4T30/EFV';ElseIf Regimen In ('d4T-3TC-LPV/r') Then Return '3TC/D4T30/LOP';ElseIf Regimen In ('ZDV-3TC-NVP') Then Return '3TC/AZT/NVP';ElseIf Regimen In ('ZDV-3TC-EFV') Then Return '3TC/AZT/EFV';ElseIf Regimen In ('ZDV-3TC-LPV/r') Then Return '3TC/AZT/LOP';ElseIf Regimen In ('ABC-3TC-EFV') Then Return '3TC/ABC/EFV';ElseIf Regimen In ('ABC-3TC-NVP') Then Return '3TC/ABC/NVP';ElseIf Regimen In ('ABC-3TC-LPV/r') Then Return '3TC/ABC/LOP';ElseIf Regimen In ('3TC-TNF-EFV') Then Return '3TC/EFV/TDF';ElseIf Regimen In ('3TC-TNF-NVP') Then Return '3TC/NVP/TDF'; ElseIf Regimen In ('TNF-3TC-LPV/r') Then Return '3TC/LOP/TDF'; Else Return 'Others'; End If; End If; End */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_DateAdd` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_DateAdd`(interv varchar(2), increment int, date1 datetime) RETURNS datetime Begin if interv='dd' or interv = 'd' then return date_add(date1, interval increment day); elseif interv='mm' or interv = 'm' then return date_add(date1, interval increment month); elseif interv='yy' or interv = 'y' then return date_add(date1, interval increment year); else return null;end if;end */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_DateDiff` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_DateDiff`(interv varchar(2), date1 datetime, date2 datetime) RETURNS int(11) Begin if interv='dd' or interv = 'd' then return datediff(date2,date1); elseif interv='mm' or interv = 'm' then return floor(datediff(date2,date1)/30.25);elseif interv='yy' or interv = 'y' then return floor(datediff(date2,date1)/365.25);else return null;end if;end */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_DateName` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_DateName`(interv varchar(2), date1 datetime) RETURNS varchar(20) CHARSET latin1 Begin if(interv = 'dd' or interv = 'd') Then return date_format(date1,'%W'); Elseif (interv = 'mm' or interv = 'm') Then return date_format(date1,'%M');Elseif(interv = 'yy' or interv = 'y') Then return date_format(date1,'%Y'); Else return null; End If;End */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_GetAge` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_GetAge`(DOB datetime, todate datetime) RETURNS int(11) Begin return Floor(datediff(todate,DOB)/365.25); End */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_GetAgeGroup` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_GetAgeGroup`(age int, type varchar(20)) RETURNS varchar(20) CHARSET latin1 Begin DECLARE AgeGroup varchar(6); IF(Type='PEPFAR') Then SET AgeGroup =CASE WHEN Age Between 0 And 1 Then '0-1' WHEN Age Between 2 And 4 Then '2-4' WHEN Age Between 5 And 14 Then '5-14' WHEN Age >14 Then 'Adult' END;ELSEIF(Type='MRN') Then SET AgeGroup = CASE WHEN Age Between 0 And 1 Then '0-1' WHEN Age Between 2 And 4 Then '2-4' WHEN Age Between 5 And 14 Then '5-14' WHEN Age Between 15 and 17 Then '15-17' WHEN Age >17 Then 'Adult' END; ELSEIF(Type='KENYA') Then SET AgeGroup = CASE WHEN Age Between 0 And 18 Then '0-18' WHEN Age >18 Then 'Adult' END; ELSEIF (Type='NORMAL') Then SET AgeGroup = CASE WHEN Age Between 0 And 14 Then '0-14' WHEN Age >14 Then 'Adult' END; ELSEIF (Type='SCM') Then SET AgeGroup = CASE WHEN Age Between 0 And 15 Then 'Child' WHEN Age >15 Then 'Adult' END; ELSEIF (Type='OLDER') Then SET AgeGroup = CASE WHEN Age Between 0 And 1 Then '0-1' when Age Between 2 And 4 then '2-4' when Age Between 5 and 14 then '5-14' when Age Between 15 and 20 then '15-20' when Age Between 21 and 30 then '21-30' when Age Between 31 and 40 then '31-40' when Age Between 41 and 50 then '41-50' when Age >=51 then 'Over50' END; ELSEIF (Type='UGANDA') Then SET AgeGroup = CASE WHEN Age = 0 Then '0' when Age =1 then '1' when Age Between 2 and 4 then '2-4' when Age Between 5 and 9 then '5-9' when Age Between 10 and 14 then '10-14' when Age Between 15 and 17 then '15-17' when Age Between 18 and 24 then '18-24' when Age >=25 then 'Adult' END;ELSEIF (Type='UMoH') Then SET AgeGroup = CASE WHEN Age = 0 Then '0' when Age Between 1 And 4 then '1-4' when Age Between 5 And 14 then '5-14' when Age>=15 then 'Adult' END; End If; RETURN AgeGroup; end */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
/*!50003 DROP FUNCTION IF EXISTS `fn_GetTestCategory` */;;
/*!50003 SET SESSION SQL_MODE=""*/;;
/*!50003 CREATE*/ /*!50020 DEFINER=`itechapp`@`%`*/ /*!50003 FUNCTION `fn_GetTestCategory`(StartARTDate datetime, ComparisonDate datetime) RETURNS int(11) Begin Return FLOOR(CASE WHEN (DATEDIFF(ComparisonDate, StartARTDate)%180)/180.0 > 0.67 THEN ROUND(DATEDIFF(ComparisonDate, StartARTDate)/180.0,0) WHEN (DATEDIFF(ComparisonDate, StartARTDate)%180)/180.0 < 0.17 Then FLOOR(DATEDIFF(ComparisonDate, StartARTDate)/180) ELSE NULL END * 6); End */;;

/*!50003 SET SESSION SQL_MODE=@OLD_SQL_MODE*/;;
DELIMITER ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-11-12 10:21:13
