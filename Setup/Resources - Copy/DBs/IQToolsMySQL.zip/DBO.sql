-- MySQL dump 10.13  Distrib 5.1.72, for Win64 (unknown)
--
-- Host: localhost    Database: dbo
-- ------------------------------------------------------
-- Server version	5.1.72-community-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

/*!40000 DROP DATABASE IF EXISTS `dbo`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `dbo` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `dbo`;

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
--  Procedure definition for `fn_CDCRegimens`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_CDCRegimens`;
DELIMITER ;;
CREATE  FUNCTION `fn_CDCRegimens`(Regimen varchar(50), RegType varchar(50)) RETURNS varchar(20) CHARSET latin1
Begin If(RegType='isante') Then If Regimen In ('d4T-3TC-NVP') Then Return '3TC/D4T30/NVP';ElseIf Regimen In ('d4T-3TC-EFV') Then Return '3TC/D4T30/EFV';ElseIf Regimen In ('d4T-3TC-LPV/r') Then Return '3TC/D4T30/LOP';ElseIf Regimen In ('ZDV-3TC-NVP') Then Return '3TC/AZT/NVP';ElseIf Regimen In ('ZDV-3TC-EFV') Then Return '3TC/AZT/EFV';ElseIf Regimen In ('ZDV-3TC-LPV/r') Then Return '3TC/AZT/LOP';ElseIf Regimen In ('ABC-3TC-EFV') Then Return '3TC/ABC/EFV';ElseIf Regimen In ('ABC-3TC-NVP') Then Return '3TC/ABC/NVP';ElseIf Regimen In ('ABC-3TC-LPV/r') Then Return '3TC/ABC/LOP';ElseIf Regimen In ('3TC-TNF-EFV') Then Return '3TC/EFV/TDF';ElseIf Regimen In ('3TC-TNF-NVP') Then Return '3TC/NVP/TDF'; ElseIf Regimen In ('TNF-3TC-LPV/r') Then Return '3TC/LOP/TDF'; Else Return 'Others'; End If; End If; End
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_DateAdd`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_DateAdd`;
DELIMITER ;;
CREATE  FUNCTION `fn_DateAdd`(interv varchar(2), increment int, date1 datetime) RETURNS datetime
Begin if interv='dd' or interv = 'd' then return date_add(date1, interval increment day); elseif interv='mm' or interv = 'm' then return date_add(date1, interval increment month); elseif interv='yy' or interv = 'y' then return date_add(date1, interval increment year); else return null;end if;end
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_DateDiff`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_DateDiff`;
DELIMITER ;;
CREATE  FUNCTION `fn_DateDiff`(interv varchar(2), date1 datetime, date2 datetime) RETURNS int(11)
Begin if interv='dd' or interv = 'd' then return datediff(date2,date1); elseif interv='mm' or interv = 'm' then return floor(datediff(date2,date1)/30.25);elseif interv='yy' or interv = 'y' then return floor(datediff(date2,date1)/365.25);else return null;end if;end
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_DateName`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_DateName`;
DELIMITER ;;
CREATE  FUNCTION `fn_DateName`(interv varchar(2), date1 datetime) RETURNS varchar(20) CHARSET latin1
Begin if(interv = 'dd' or interv = 'd') Then return date_format(date1,'%W'); Elseif (interv = 'mm' or interv = 'm') Then return date_format(date1,'%M');Elseif(interv = 'yy' or interv = 'y') Then return date_format(date1,'%Y'); Else return null; End If;End
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_GetAge`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_GetAge`;
DELIMITER ;;
CREATE  FUNCTION `fn_GetAge`(DOB datetime, todate datetime) RETURNS int(11)
Begin return Floor(datediff(todate,DOB)/365.25); End
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_GetAgeGroup`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_GetAgeGroup`;
DELIMITER ;;
CREATE  FUNCTION `fn_GetAgeGroup`(age decimal, type varchar(20)) RETURNS varchar(20) CHARSET latin1
Begin DECLARE AgeGroup varchar(6); 
IF(Type='PEPFAR') Then SET AgeGroup =CASE WHEN Age Between 0 And 1 Then '0-1' WHEN Age Between 2 And 4 Then '2-4' 
WHEN Age Between 5 And 14 Then '5-14' WHEN Age >14 Then 'Adult' END;
ELSEIF(Type='MRN') 
Then SET AgeGroup = CASE WHEN Age Between 0 And 1 Then '0-1' WHEN Age Between 2 And 4 Then '2-4' WHEN Age Between 5 And 14 Then '5-14' 
WHEN Age Between 15 and 17 Then '15-17' WHEN Age >17 Then 'Adult' END; 
ELSEIF(Type='KENYA') Then SET AgeGroup = CASE WHEN Age Between 0 And 18 Then '0-18' WHEN Age >18 Then 'Adult' END; 
ELSEIF (Type='NORMAL') Then 
SET AgeGroup = CASE WHEN Age Between 0 And 14.9 Then '0-14' 
				WHEN Age >=15 Then 'Adult' END; 
ELSEIF (Type='SCM') Then SET AgeGroup = CASE WHEN Age Between 0 And 15 Then 'Child' WHEN Age >15 Then 'Adult' END; 
ELSEIF (Type='OLDER') Then SET AgeGroup = CASE WHEN Age Between 0 And 1 Then '0-1' when Age Between 2 And 4 then '2-4' 
when Age Between 5 and 14 then '5-14' when Age Between 15 and 20 then '15-20' when Age Between 21 and 30 then '21-30' 
when Age Between 31 and 40 then '31-40' when Age Between 41 and 50 then '41-50' when Age >=51 then 'Over50' END; 
ELSEIF (Type='UGANDA') Then SET AgeGroup = CASE WHEN Age = 0 Then '0' when Age =1 then '1' when Age Between 2 and 4 then '2-4' 
when Age Between 5 and 9 then '5-9' when Age Between 10 and 14 then '10-14' when Age Between 15 and 17 then '15-17' when Age 
Between 18 and 24 then '18-24' when Age >=25 then 'Adult' END;ELSEIF (Type='UMoH') Then SET AgeGroup = CASE WHEN Age = 0 Then '0' 
when Age Between 1 And 4 then '1-4' when Age Between 5 And 14 then '5-14' when Age>=15 then 'Adult' END; End If; RETURN AgeGroup; 
end
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_GetCurrentDate`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_GetCurrentDate`;
DELIMITER ;;
CREATE  FUNCTION `fn_GetCurrentDate`() RETURNS datetime
Begin
Return Now();
End
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_GetTestCategory`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_GetTestCategory`;
DELIMITER ;;
CREATE  FUNCTION `fn_GetTestCategory`(StartARTDate datetime, ComparisonDate datetime) RETURNS int(11)
Begin Return FLOOR(CASE WHEN (DATEDIFF(ComparisonDate, StartARTDate)%180)/180.0 > 0.67 THEN ROUND(DATEDIFF(ComparisonDate, StartARTDate)/180.0,0) WHEN (DATEDIFF(ComparisonDate, StartARTDate)%180)/180.0 < 0.17 Then FLOOR(DATEDIFF(ComparisonDate, StartARTDate)/180) ELSE NULL END * 6); End
;;
DELIMITER ;

-- ----------------------------
--  Procedure definition for `fn_YMDToDate`
-- ----------------------------
DROP FUNCTION IF EXISTS `fn_YMDToDate`;
DELIMITER ;;
CREATE  FUNCTION `fn_YMDToDate`(year VARCHAR(4), month VARCHAR(2), day VARCHAR(2)) RETURNS datetime
BEGIN 
DECLARE inYear CHAR(4);  
DECLARE inMonth, inDay CHAR(2);  
DECLARE outYear CHAR(4); 
DECLARE outMonth, outDay CHAR(2); 
  
SET inYear = TRIM(year);  SET inMonth = TRIM(month);  SET inDay = TRIM(day);   

IF IsNumeric(inYear)  THEN   
	IF inYear >= 1000     
		THEN SET outYear = inYear;   
	ELSEIF inYear <20   
		THEN SET outYear = inYear + 2000;   
		ELSE       SET outYear = inYear + 1900;    
		END IF;  
ELSE SET outYear = Null;  
END IF;  

IF IsNumeric(inMonth) AND inMonth <> '00' AND inMonth <> '0'  
	THEN   IF LENGTH(inMonth) = 1      
	THEN SET outMonth = CONCAT('0', inMonth);   
	ELSE SET outMonth = inMonth;      
END IF;  
ELSE   
	SET outMonth = '06';  END IF;    

IF IsNumeric(inDay) AND inDay <> '00' AND inDay <> '0' 
	THEN   
		IF LENGTH(inDay) = 1      
		THEN SET outDay = CONCAT('0', inDay);   
		ELSE SET outDay = inDay;  
		END IF;  
ELSE  SET outDay = '15';  
END IF;   
RETURN Cast((CONCAT(outYear, '/', outMonth, '/', outDay)) As date);    
END
;;
DELIMITER ;

-- ----------------------------
--  Records 
-- ----------------------------
